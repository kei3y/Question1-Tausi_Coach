/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questionThree;

/**
 *
 * @author Kei3ron
 */
import java.time.LocalTime;
public class arrivalTime {
    public static void main(String[] args) {
        tausiCoach tausiCoach = new tausiCoach(10000, 150, 200, 250.0, 5);
        int totalStops = tausiCoach.calculateTotalStops();
        double totalTravelTime = tausiCoach.calculateTotalTravelTime();
        double returnJourneyTime = tausiCoach.calculateReturnJourneyTime();

        System.out.println("Total stops from Kampala to Kabale " + totalStops);
        System.out.println("Total travel time from Kampala to Kabale " + totalTravelTime + " hours");
        System.out.println("Total time spent on return journey " + returnJourneyTime + " hours");

        secondCoach secondCoach = new secondCoach(10000, 225.5);
        LocalTime departureTime = LocalTime.of(9, 0);
        LocalTime arrivalTime = secondCoach.calculateArrivalTime(departureTime);

        System.out.println("The second coach will arrive at " + arrivalTime + "HOURS");
    }
}