package questionThree;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Kei3ron
 */
public class tausiCoach {
    private int totalDistance;
    private int stopDistance;
    private int fuelDistance;
    private double speedKmHr;
    private double stopTimeMinutes;

    public tausiCoach(int totalDistance, int stopDistance, int fuelDistance, double speedKmHr, double stopTimeMinutes) {
        this.totalDistance = totalDistance;
        this.stopDistance = stopDistance;
        this.fuelDistance = fuelDistance;
        this.speedKmHr = speedKmHr;
        this.stopTimeMinutes = stopTimeMinutes;
    }
    public int calculateTotalStops() {
        int loadStops = totalDistance / stopDistance;
        int fuelStops = totalDistance / fuelDistance;
        return Math.max(loadStops, fuelStops);
    }
    public double calculateTotalTravelTime() {
        double travelTimeHours = totalDistance / speedKmHr;
        int numberOfStops = calculateTotalStops();
        double totalStopTimeHours = (numberOfStops * stopTimeMinutes) / 60.0;
        return travelTimeHours + totalStopTimeHours;
    }
    public double calculateReturnJourneyTime() {
        double travelTimeHours = totalDistance / speedKmHr;
        int numberOfStops = totalDistance / fuelDistance;
        double totalStopTimeHours = (numberOfStops * stopTimeMinutes) / 60.0;
        return travelTimeHours + totalStopTimeHours;
    }
}
