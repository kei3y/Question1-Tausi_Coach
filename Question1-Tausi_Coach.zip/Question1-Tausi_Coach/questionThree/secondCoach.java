/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questionThree;

/**
 *
 * @author Kei3ron
 */
 import java.time.LocalTime;
public class secondCoach {
    private double totalDistanceKm;
    private double speedMs;    

    public secondCoach(double totalDistanceKm, double speedMs) {
        this.totalDistanceKm = totalDistanceKm;
        this.speedMs = speedMs;
    }

    public LocalTime calculateArrivalTime(LocalTime departureTime) {
        double speedKmHr = speedMs * 3.6;
        double travelTimeHours = totalDistanceKm / speedKmHr;
        return departureTime.plusMinutes((long) (travelTimeHours * 60));
    }
}
